DASTAN AIM BOT — Android overlay demo

This is source code for a simple movable floating panel with animated buttons.
It is NOT an APK. It must be built into an APK using an Android build environment.
The panel is a harmless UI demo only: it does not read, modify, automate, or interact
with Free Fire, and it does not provide aiming or headshot functionality.

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your POCO M7.
5. Open the app and grant "Display over other apps" permission.
6. Tap the panel button to show the overlay.

Android may restrict overlays over some full-screen games. This project does not
guarantee that the panel will be visible over Free Fire.
