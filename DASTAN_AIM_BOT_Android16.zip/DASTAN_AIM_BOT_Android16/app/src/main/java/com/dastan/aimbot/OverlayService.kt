package com.dastan.aimbot

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(24, 24, 30))
        }
        val header = TextView(this).apply {
            text = "✦ DASTAN AIM BOT"
            textSize = 17f
            setTextColor(Color.rgb(255, 65, 75))
            setPadding(4, 4, 4, 12)
        }
        box.addView(header)

        fun addButton(label: String, action: () -> Unit) {
            val item = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(18, 13, 18, 13)
                setBackgroundColor(Color.rgb(145, 28, 38))
                setOnClickListener { action() }
            }
            val anim = AlphaAnimation(0.72f, 1f).apply {
                duration = 650
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            }
            item.startAnimation(anim)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
            box.addView(item, lp)
        }

        addButton("HEADSHOT TRAINING") { header.text = "✦ ТРЕНИРОВКА ВКЛЮЧЕНА" }
        addButton("AIM PRACTICE") { header.text = "✦ ТРЕНИРОВКА ПРИЦЕЛА" }
        addButton("HIDE PANEL") { stopSelf() }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 180
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX - (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(box, params)
                        return true
                    }
                }
                return false
            }
        })

        panel = box
        wm.addView(box, params)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
}
