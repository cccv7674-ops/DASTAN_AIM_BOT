package com.dastan.aimbot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(17, 17, 22))
        }
        root.addView(TextView(this).apply {
            text = "DASTAN AIM BOT\nANDROID 16"
            textSize = 27f
            setTextColor(Color.rgb(255, 55, 65))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Плавающая тренировочная панель"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        })
        val button = Button(this).apply { text = "РАЗРЕШИТЬ И ОТКРЫТЬ ПАНЕЛЬ" }
        button.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
            }
        }
        root.addView(button)
        root.addView(TextView(this).apply {
            text = "Панель показывает только тренировочные кнопки. Она не наводит прицел и не изменяет Free Fire."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            // Пользователь может снова нажать кнопку, чтобы открыть панель.
        }
    }
}
